﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace NPL.M.A005.Exercise2
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string works = @"Created at 28/02/2018 10:15:35 AM by Andy.
                             Updated at 03/03/2018 02:45:10 PM by Mark 
                             Clear name at 02/03/2018 11:34:05 AM by Andy";

            var arrText = works.Split('\n');

            var dateAfterSort = SortArrayByDateTime(arrText);

            foreach (var item in dateAfterSort)
            {
                Console.WriteLine(item.Trim());
            }

            Console.ReadKey();
        }

        private static string[] SortArrayByDateTime(string[] arrText)
        {
            for (int i = arrText.Length - 1; i > 0; i--)
            {
                for (int j = 0; j < arrText.Length - 1; j++)
                {
                    string pattern = @"(\d{2}\/\d{2}\/\d{4}) (\d{2}\:\d{2}\:\d{2}) (AM|PM)";

                    var firstMatch = Regex.Match(arrText[j], pattern).Value;

                    var secondMatch = Regex.Match(arrText[j + 1], pattern).Value;

                    DateTime.TryParseExact(firstMatch, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime firstDate);

                    DateTime.TryParseExact(secondMatch, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime secondDate);

                    if (firstDate.CompareTo(secondDate) > 0)
                    {
                        var temp = arrText[j];
                        arrText[j] = arrText[j + 1];
                        arrText[j + 1] = temp;
                    }
                }
            }

            return arrText;
        }
    }
}
