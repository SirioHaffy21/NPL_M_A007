﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace NPL.M.A005.Exercise1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            DateTime dateSubmited;

            while (true)
            {
                Console.WriteLine("Please enter your date by format 'dd/MM/yyyy': ");

                var input = Console.ReadLine();

                if (DateTime.TryParseExact(input, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateSubmited))
                {
                    break;
                }
            }

            var listDateRemider = GenerateRemindDate(dateSubmited);

            var listDateMessage = GenerateRemindMessage(listDateRemider);

            foreach (var item in listDateMessage)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();
        }

        private static List<string> GenerateRemindMessage(List<DateTime> listDateRemider)
        {
            List<string> listRemindMessage = new List<string>();

            for (int i = 0; i < listDateRemider.Count; i++)
            {
                var order = i + 1 == 1 ? "st" : i + 1 == 2 ? "nd" : i + 1 == 3 ? "rd" : "th";
                listRemindMessage.Add($"{i + 1} {order} reminder: " + listDateRemider[i]);
            }

            return listRemindMessage;
        }

        private static List<DateTime> GenerateRemindDate(DateTime dateSubmited)
        {
            List<DateTime> listDateRemider = new List<DateTime>();
            int count = 0;

            while (true)
            {
                dateSubmited = dateSubmited.AddDays(1);

                if (dateSubmited.DayOfWeek != DayOfWeek.Saturday && dateSubmited.DayOfWeek != DayOfWeek.Sunday)
                {
                    ++count;
                    if (count == 7 || count == 9 || count == 10 || count == 11 || count == 12)
                    {
                        listDateRemider.Add(dateSubmited);
                    }

                    if (count > 12)
                    {
                        break;
                    }
                }
            }

            return listDateRemider;
        }
    }
}
